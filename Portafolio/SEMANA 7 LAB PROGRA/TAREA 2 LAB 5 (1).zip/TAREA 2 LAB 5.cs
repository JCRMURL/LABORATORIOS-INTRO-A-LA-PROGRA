using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese el monto de la compra:");
        string input = Console.ReadLine();

        if (string.IsNullOrEmpty(input))
        {
            Console.WriteLine("Error: Debe ingresar un monto válido.");
            return;
        }

        double monto = double.Parse(input);

        double descuento = 0;

        if (monto < 400)
        {
            descuento = 0;
        }
        else if (monto >= 400 && monto <= 1000)
        {
            descuento = monto * 0.07;
        }
        else if (monto > 1000 && monto <= 5000)
        {
            descuento = monto * 0.10;
        }
        else if (monto > 5000 && monto <= 15000)
        {
            descuento = monto * 0.15;
        }
        else if (monto > 15000)
        {
            descuento = monto * 0.25;
        }

        Console.WriteLine("Ingrese el código de descuento (si tiene):");
        string codigoDescuento = Console.ReadLine();

        if (!string.IsNullOrEmpty(codigoDescuento))
        {
            descuento += monto * 0.05;
        }

        double montoFinal = monto - descuento;

        Console.WriteLine("Monto a pagar final: " + montoFinal);
    }
}
