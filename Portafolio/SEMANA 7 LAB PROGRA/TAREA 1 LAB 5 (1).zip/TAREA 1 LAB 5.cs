using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese el monto 1:");
        double monto1 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese la moneda del monto 1 (USD o GTQ):");
        string moneda1 = Console.ReadLine();

        Console.WriteLine("Ingrese el monto 2:");
        double monto2 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese la moneda del monto 2 (USD o GTQ):");
        string moneda2 = Console.ReadLine();

        Console.WriteLine("Ingrese el monto 3:");
        double monto3 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese la moneda del monto 3 (USD o GTQ):");
        string moneda3 = Console.ReadLine();

        double tipoCambio = 7.83;

        double[] montosEnQuetzales = new double[3];

        if (moneda1 == "USD")
        {
            montosEnQuetzales[0] = monto1 * tipoCambio;
        }
        else
        {
            montosEnQuetzales[0] = monto1;
        }

        if (moneda2 == "USD")
        {
            montosEnQuetzales[1] = monto2 * tipoCambio;
        }
        else
        {
            montosEnQuetzales[1] = monto2;
        }

        if (moneda3 == "USD")
        {
            montosEnQuetzales[2] = monto3 * tipoCambio;
        }
        else
        {
            montosEnQuetzales[2] = monto3;
        }

        Array.Sort(montosEnQuetzales);

        Console.WriteLine("Montos en quetzales en orden ascendente:");
        foreach (double monto in montosEnQuetzales)
        {
            Console.WriteLine(monto);
        }
    }
}
