using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1");

        Console.Write("Número ENTERO: ");
        string input = Console.ReadLine();

        int numero;
        if (int.TryParse(input, out numero))
        {
            if (numero > 0)
            {
                Console.WriteLine("RESULTADO: El número es positivo");
            }
            else if (numero < 0)
            {
                Console.WriteLine("RESULTADO: El número es negativo");
            }
            else
            {
                Console.WriteLine("RESULTADO: El número es cero");
            }
        }
        else
        {
            Console.WriteLine("ERROR: No se ha ingresado un número válido");
        }
    }
}
